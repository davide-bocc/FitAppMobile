#include "test.h"

void foo() {}